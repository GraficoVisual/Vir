import { createFileRoute, Link } from "@tanstack/react-router";
import { HeroSlides } from "@/components/HeroSlides";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Construcciones Vir — Construyendo desde 1978 · Gijón" },
      { name: "description", content: "Empresa de construcción en Gijón con más de 40 años de experiencia. Edificios de viviendas, rehabilitaciones integrales, fachadas catalogadas y obra unifamiliar en Asturias." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:title", content: "Construcciones Vir — Gijón" },
      { property: "og:description", content: "Construyendo desde 1978. Edificios, rehabilitaciones y obra singular en Asturias." },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <div className="bg-background text-foreground">
      <SiteHeader />

      {/* HERO */}
      <section className="relative h-[100svh] w-full overflow-hidden">
        <HeroSlides />
        <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-black/12 to-black/55" />
        <div className="relative z-10 mx-auto flex h-full max-w-[1600px] flex-col justify-between px-6 pb-12 pt-32 text-background md:px-12 md:pb-16 md:pt-40">
          <div className="reveal delay-1">
            <p className="eyebrow opacity-80">— Empresa de construcción · Gijón · desde 1978</p>
          </div>
          <div className="max-w-5xl">
            <h1 className="display reveal delay-2 text-[clamp(1.3rem,4.3vw_+_0.42rem,3.75rem)] max-sm:text-[1.3rem]">
              Compromiso con la arquitectura<br />
              <span className="opacity-70 whitespace-nowrap max-sm:whitespace-normal">desde 1978</span>
            </h1>
            <div className="mt-12 flex flex-col gap-6 reveal delay-3 md:flex-row md:items-end md:justify-between">
              <p className="max-w-md text-sm opacity-85">
                Edificios de viviendas, rehabilitaciones integrales, fachadas catalogadas y obra unifamiliar en Asturias. Más de cuatro décadas de oficio.
              </p>
              <div className="flex items-center gap-8">
                <Link to="/empresa" className="eyebrow underline-grow accent">Conocer la empresa →</Link>
                <Link to="/contacto" className="eyebrow underline-grow opacity-70 hover:opacity-100">Contacto</Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* MARQUEE */}
      <section className="border-y hairline overflow-hidden py-6">
        <div className="marquee-mask flex">
          <div className="animate-marquee flex shrink-0 items-center gap-16 pr-16 eyebrow opacity-60">
            {Array.from({ length: 2 }).map((_, i) => (
              <div key={i} className="flex shrink-0 items-center gap-16">
                <span>NUEVA CONSTRUCCIÓN</span><span>·</span>
                <span>REHABILITACIONES INTEGRALES</span><span>·</span>
                <span>FACHADAS CATALOGADAS</span><span>·</span>
                <span>VIVIENDAS UNIFAMILIARES</span><span>·</span>
                <span>OBRA INDUSTRIAL Y SINGULAR</span><span>·</span>
                <span>GIJÓN — ASTURIAS — DESDE 1978</span><span>·</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* EMPRESA */}
      <section className="mx-auto max-w-[1600px] px-6 py-28 md:px-12 md:py-40">
        <div className="grid gap-16 md:grid-cols-12">
          <div className="md:col-span-4">
            <p className="eyebrow opacity-60">— La empresa</p>
            <p className="eyebrow mt-4 opacity-50">N°01 / 1978 — Hoy</p>
          </div>
          <div className="md:col-span-8">
            <h2 className="display text-3xl md:text-6xl">
              Una constructora paciente,
              <span className="opacity-50"> hecha del oficio, la palabra y el detalle bien resuelto.</span>
            </h2>
            <div className="mt-12 grid gap-10 md:grid-cols-2">
              <p className="text-sm leading-relaxed opacity-80">
                Construcciones Vir es una empresa familiar con sede en Gijón, especializada en edificios de viviendas, rehabilitaciones integrales y obra singular en Asturias. Más de cuatro décadas de oficio respaldadas por una red consolidada de industriales de confianza.
              </p>
              <p className="text-sm leading-relaxed opacity-80">
                La rehabilitación de edificios catalogados y la recuperación de fachadas históricas son una de nuestras especialidades más reconocidas, con varios trabajos galardonados en los Concursos de Fachadas convocados por ASPROCON.
              </p>
            </div>
            <div className="mt-16 grid grid-cols-3 gap-8 border-t hairline pt-8">
              <div><p className="display text-3xl md:text-5xl">1978</p><p className="eyebrow mt-2 opacity-60">Fundación</p></div>
              <div><p className="display text-3xl md:text-5xl">+40</p><p className="eyebrow mt-2 opacity-60">Años</p></div>
              <div><p className="display text-3xl md:text-5xl">04</p><p className="eyebrow mt-2 opacity-60">Premios ASPROCON</p></div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA / CONTACTO */}
      <section id="contacto" className="mx-auto max-w-[1600px] px-6 py-28 md:px-12 md:py-44">
        <div className="grid gap-16 md:grid-cols-12">
          <div className="md:col-span-7">
            <p className="eyebrow opacity-60">— Contacto</p>
            <h2 className="display mt-6 text-5xl md:text-8xl">
              ¿Hablamos<br />
              <span className="opacity-50">de su proyecto?</span>
            </h2>
            <p className="mt-10 max-w-md text-sm opacity-75">
              Cuéntenos brevemente la idea, el lugar y el plazo. Le respondemos a la mayor brevedad posible.
            </p>
            <Link to="/contacto" className="eyebrow underline-grow mt-12 inline-block accent">
              Iniciar conversación →
            </Link>
          </div>
          <div className="md:col-span-5 md:pt-10">
            <div className="space-y-8 border-l hairline pl-8">
              <div>
                <p className="eyebrow opacity-50">Oficina</p>
                <p className="mt-2 text-sm">C/ Domínguez Gil 2, 2ºA<br />33201 Gijón · Asturias</p>
              </div>
              <div>
                <p className="eyebrow opacity-50">Email</p>
                <p className="mt-2 text-sm">info@construccionesvir.com</p>
              </div>
              <div>
                <p className="eyebrow opacity-50">Teléfono</p>
                <p className="mt-2 text-sm">+34 985 345 710</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}
