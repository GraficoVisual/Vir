import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";

export const Route = createFileRoute("/contacto")({
  head: () => ({
    meta: [
      { title: "Contacto — Construcciones Vir · Gijón" },
      { name: "description", content: "Para cualquier consulta rellene el formulario y nos pondremos en contacto a la mayor brevedad posible. Gijón, Asturias." },
      { property: "og:title", content: "Contacto — Construcciones Vir" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:description", content: "Hablemos de su proyecto. Gijón, Asturias." },
    ],
  }),
  component: ContactoPage,
});

function ContactoPage() {
  const [sent, setSent] = useState(false);

  return (
    <div className="bg-background text-foreground">
      <SiteHeader />

      <section className="mx-auto max-w-[1600px] px-6 pb-16 pt-40 md:px-12 md:pb-20 md:pt-48">
        <p className="eyebrow opacity-60">— Contacto</p>
        <h1 className="display mt-6 max-w-5xl text-5xl md:text-9xl">
          Cuéntenos<br /><span className="opacity-50">su proyecto.</span>
        </h1>
      </section>

      <section className="mx-auto max-w-[1600px] px-6 pb-28 md:px-12 md:pb-40">
        <div className="grid gap-16 md:grid-cols-12">
          <div className="md:col-span-7">
            {sent ? (
              <div className="border-t hairline pt-12">
                <p className="eyebrow opacity-50">— Mensaje recibido</p>
                <h2 className="display mt-6 text-3xl md:text-5xl">Gracias.<br />Respondemos en menos de 48 horas.</h2>
              </div>
            ) : (
              <form
                onSubmit={(e) => { e.preventDefault(); setSent(true); }}
                className="border-t hairline"
              >
                {[
                  { id: "nombre", label: "Nombre", type: "text" },
                  { id: "email", label: "Email", type: "email" },
                  { id: "telefono", label: "Teléfono", type: "tel" },
                  { id: "lugar", label: "Lugar del proyecto", type: "text" },
                ].map((f) => (
                  <div key={f.id} className="grid grid-cols-12 items-center gap-4 border-b hairline py-5">
                    <label htmlFor={f.id} className="eyebrow col-span-12 opacity-60 md:col-span-3">{f.label}</label>
                    <input
                      id={f.id}
                      type={f.type}
                      required
                      className="col-span-12 bg-transparent text-base outline-none placeholder:opacity-30 md:col-span-9"
                      placeholder="—"
                    />
                  </div>
                ))}
                <div className="grid grid-cols-12 gap-4 border-b hairline py-5">
                  <label htmlFor="msg" className="eyebrow col-span-12 opacity-60 md:col-span-3">Proyecto</label>
                  <textarea
                    id="msg"
                    rows={5}
                    required
                    className="col-span-12 resize-none bg-transparent text-base outline-none placeholder:opacity-30 md:col-span-9"
                    placeholder="Cuéntanos brevemente la idea, el lugar y el plazo."
                  />
                </div>
                <button type="submit" className="mt-12 eyebrow underline-grow accent">
                  Enviar mensaje →
                </button>
              </form>
            )}
          </div>

          <aside className="md:col-span-4 md:col-start-9 space-y-10">
            <div className="border-t hairline pt-6">
              <p className="eyebrow opacity-50">Oficina</p>
              <p className="mt-3 text-sm">C/ Domínguez Gil 2, 2ºA<br />33201 Gijón · Asturias</p>
            </div>
            <div className="border-t hairline pt-6">
              <p className="eyebrow opacity-50">Teléfono</p>
              <p className="mt-3 text-sm">+34 985 345 710<br />Fax 985 346 233</p>
            </div>
            <div className="border-t hairline pt-6">
              <p className="eyebrow opacity-50">Email</p>
              <p className="mt-3 text-sm">info@construccionesvir.com</p>
            </div>
          </aside>
        </div>
      </section>

      <section className="border-t hairline">
        <div className="mx-auto max-w-[1600px] px-6 py-2 md:px-12">
          <p className="eyebrow opacity-50">— Localización</p>
        </div>
        <div className="relative h-[60svh] w-full overflow-hidden bg-secondary">
          <iframe
            title="Construcciones Vir — Gijón"
            src="https://www.openstreetmap.org/export/embed.html?bbox=-5.668%2C43.539%2C-5.654%2C43.546&layer=mapnik&marker=43.5425%2C-5.6612"
            className="absolute inset-0 h-full w-full grayscale contrast-110"
            loading="lazy"
          />
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}
