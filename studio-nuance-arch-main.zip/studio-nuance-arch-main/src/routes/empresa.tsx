import { createFileRoute } from "@tanstack/react-router";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";

export const Route = createFileRoute("/empresa")({
  head: () => ({
    meta: [
      { title: "Empresa — Construcciones Vir" },
      { name: "description", content: "Empresa constructora con sede en Gijón. Más de 40 años construyendo viviendas, rehabilitaciones y obra singular en Asturias." },
      { property: "og:title", content: "Empresa — Construcciones Vir" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:description", content: "Construyendo desde 1978 en Gijón." },
    ],
  }),
  component: EmpresaPage,
});

function EmpresaPage() {
  return (
    <div className="bg-background text-foreground">
      <SiteHeader />

      <section className="mx-auto max-w-[1600px] px-6 pb-16 pt-40 md:px-12 md:pb-28 md:pt-48">
        <p className="eyebrow opacity-60">— La empresa</p>
        <h1 className="display mt-6 max-w-5xl text-5xl md:text-9xl">
          Construyendo<br />
          <span className="opacity-50">desde 1978.</span>
        </h1>
      </section>

      <section className="mx-auto max-w-[1600px] px-6 py-28 md:px-12 md:py-40">
        <div className="grid gap-16 md:grid-cols-12">
          <p className="eyebrow opacity-60 md:col-span-3">— Quiénes somos</p>
          <div className="md:col-span-8 space-y-10">
            <p className="display text-2xl md:text-4xl">
              Empresa de construcción con más de 40 años de experiencia en el sector, ejecutando edificios de viviendas, rehabilitaciones integrales de edificios catalogados, viviendas unifamiliares, naves industriales y obra singular.
            </p>
            <div className="grid gap-10 md:grid-cols-2">
              <p className="text-sm opacity-80 leading-relaxed">
                La rehabilitación de edificios es una de nuestras especialidades más reconocidas y uno de nuestros principales aspectos diferenciadores. Un campo que ha tenido un gran auge en los últimos años por la conservación del patrimonio arquitectónico y por una mayor demanda social que aprecia el cuidado del paisaje urbano.
              </p>
              <p className="text-sm opacity-80 leading-relaxed">
                Desde el primer momento nuestro trabajo ha consistido en respaldar, asesorar y orientar al cliente de un modo integral: en la adopción de soluciones técnicas idóneas y en los aspectos legales y burocráticos que, por experiencia, dominamos.
              </p>
            </div>

            <div className="grid grid-cols-3 gap-8 border-t hairline pt-8">
              <div><p className="display text-3xl md:text-5xl">1978</p><p className="eyebrow mt-2 opacity-60">Fundación</p></div>
              <div><p className="display text-3xl md:text-5xl">+40</p><p className="eyebrow mt-2 opacity-60">Años de oficio</p></div>
              <div><p className="display text-3xl md:text-5xl">04</p><p className="eyebrow mt-2 opacity-60">Premios ASPROCON</p></div>
            </div>
          </div>
        </div>
      </section>

      <section className="border-y hairline bg-secondary/30 py-28 md:py-40">
        <div className="mx-auto max-w-[1600px] px-6 md:px-12">
          <p className="eyebrow opacity-60 mb-12">— Reconocimientos</p>
          <h2 className="display text-3xl md:text-5xl max-w-4xl">
            Galardonados en los Concursos de Fachadas a nivel regional convocados por <span className="opacity-60">ASPROCON y la Caja de Ahorros de Asturias en 1990, 1992, 2000 y 2002.</span>
          </h2>
        </div>
      </section>

      <section className="mx-auto max-w-[1600px] px-6 py-28 md:px-12 md:py-40">
        <div className="grid gap-12 md:grid-cols-3">
          {[
            { n: "01", t: "Oficio", d: "Más de cuatro décadas trabajando con los mejores oficios de Asturias. Una red consolidada de industriales de confianza." },
            { n: "02", t: "Patrimonio", d: "Especialistas en rehabilitación de edificios catalogados y fachadas históricas del centro de Gijón." },
            { n: "03", t: "Compromiso", d: "Acompañamos al cliente desde la idea inicial hasta la entrega final, con un único interlocutor responsable." },
          ].map((v) => (
            <div key={v.n} className="border-t hairline pt-6">
              <p className="eyebrow opacity-50">{v.n}</p>
              <h3 className="display mt-6 text-3xl md:text-5xl">{v.t}</h3>
              <p className="mt-6 text-sm opacity-75">{v.d}</p>
            </div>
          ))}
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}
