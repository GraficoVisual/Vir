import { useEffect, useState } from "react";
import { cn } from "@/lib/utils";
import casa from "@/assets/vivienda-geranios-ocaso.jpg.asset.json";
import fachada from "@/assets/fachada-maria-esteban.jpg.asset.json";

/**
 * scrim: oscurecido extra que necesita cada fotografía para que el texto
 * blanco de la portada se lea bien sobre ella (0 = ninguna, 1 = negro).
 */
const SLIDES = [
  { src: casa.url, alt: "Vivienda unifamiliar con piscina al atardecer", scrim: 0 },
  { src: fachada.url, alt: "Fachada rehabilitada con decoración modernista", scrim: 0.16 },
];

const DURATION = 7000;

/**
 * Fondo de portada: pase de dos fotografías con fundido cruzado.
 * Avanza solo cada DURATION ms; se puede saltar de una a otra con las
 * dos líneas finas de la parte inferior. Si la persona prefiere menos
 * movimiento, el pase no se reproduce.
 */
export function HeroSlides() {
  const [active, setActive] = useState(0);

  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const id = window.setInterval(
      () => setActive((i) => (i + 1) % SLIDES.length),
      DURATION,
    );
    return () => window.clearInterval(id);
  }, []);

  return (
    <>
      <div
        className="absolute inset-0 overflow-hidden"
        role="img"
        aria-label={`${SLIDES[0].alt}. ${SLIDES[1].alt}.`}
      >
        {SLIDES.map((slide, i) => (
          <img
            key={slide.src}
            src={slide.src}
            alt=""
            aria-hidden="true"
            width={1920}
            height={1280}
            loading="eager"
            decoding="async"
            fetchPriority={i === 0 ? "high" : "low"}
            className={cn(
              "absolute inset-0 h-full w-full object-cover",
              "transition-[opacity,transform] duration-[1800ms] ease-[cubic-bezier(0.22,1,0.36,1)]",
              i === active ? "scale-100 opacity-100" : "scale-[1.06] opacity-0",
            )}
          />
        ))}
        {SLIDES.map((slide, i) => (
          <div
            key={slide.src}
            aria-hidden="true"
            className="absolute inset-0 bg-black transition-opacity duration-[1800ms] ease-[cubic-bezier(0.22,1,0.36,1)]"
            style={{ opacity: i === active ? slide.scrim : 0 }}
          />
        ))}
      </div>

      <div className="absolute bottom-5 left-1/2 z-20 flex -translate-x-1/2 items-center gap-1">
        {SLIDES.map((slide, i) => (
          <button
            key={slide.src}
            type="button"
            onClick={() => setActive(i)}
            aria-label={`Ver la fotografía ${i + 1} de ${SLIDES.length}: ${slide.alt}`}
            aria-current={i === active}
            className="group cursor-pointer px-2 py-4"
          >
            <span
              className={cn(
                "block h-px w-8 transition-colors duration-700",
                i === active
                  ? "bg-background"
                  : "bg-background/40 group-hover:bg-background/75",
              )}
            />
          </button>
        ))}
      </div>
    </>
  );
}
