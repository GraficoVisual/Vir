import { Link, useRouterState } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import virLogo from "@/assets/vir-logo.svg";
import virLogoLight from "@/assets/vir-logo-light.svg";


const links = [
  { to: "/", label: "Inicio" },
  { to: "/empresa", label: "Empresa" },
  { to: "/contacto", label: "Contacto" },
] as const;

export function SiteHeader() {
  const { location } = useRouterState();
  const isHome = location.pathname === "/";
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => { setOpen(false); }, [location.pathname]);

  const overlay = isHome && !scrolled;

  return (
    <header
      className={[
        "fixed inset-x-0 top-0 z-50 transition-all duration-500",
        overlay ? "text-background" : "text-foreground",
        scrolled ? "bg-background/85 backdrop-blur-md border-b hairline" : "bg-transparent",
      ].join(" ")}
    >
      <div className="mx-auto flex max-w-[1600px] items-center justify-between px-6 py-5 md:px-12 md:py-6">
        <Link to="/" aria-label="Inicio — Construcciones Vir" className="flex items-center">
          <img
            src={overlay ? virLogoLight : virLogo}
            alt="Construcciones Vir"
            className="h-8 md:h-10 w-auto"
          />



        </Link>

        <nav className="hidden items-center gap-10 md:flex">
          {links.map((l) => (
            <Link
              key={l.to}
              to={l.to}
              className="eyebrow underline-grow"
              activeProps={{ className: "eyebrow underline-grow opacity-100" }}
              inactiveProps={{ className: "eyebrow underline-grow opacity-70 hover:opacity-100 transition-opacity" }}
            >
              {l.label}
            </Link>
          ))}
        </nav>

        <button
          aria-label="Abrir menú"
          onClick={() => setOpen((v) => !v)}
          className="md:hidden flex flex-col gap-1.5 p-2"
        >
          <span className={`block h-px w-6 bg-current transition-transform ${open ? "translate-y-[6px] rotate-45" : ""}`} />
          <span className={`block h-px w-6 bg-current transition-opacity ${open ? "opacity-0" : ""}`} />
          <span className={`block h-px w-6 bg-current transition-transform ${open ? "-translate-y-[6px] -rotate-45" : ""}`} />
        </button>
      </div>

      {open && (
        <div className="md:hidden bg-background text-foreground border-t hairline">
          <nav className="flex flex-col px-6 py-6">
            {links.map((l) => (
              <Link key={l.to} to={l.to} className="display text-3xl py-3">
                {l.label}
              </Link>
            ))}
          </nav>
        </div>
      )}
    </header>
  );
}
