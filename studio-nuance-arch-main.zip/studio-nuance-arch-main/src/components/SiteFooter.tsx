export function SiteFooter() {
  return (
    <footer className="border-t hairline bg-background">
      <div className="mx-auto flex max-w-[1600px] flex-col gap-3 px-6 py-10 text-xs opacity-60 md:flex-row md:items-center md:justify-between md:px-12">
        <p>© {new Date().getFullYear()} Construcciones Vir, S.L. — Todos los derechos reservados.</p>
        <p className="eyebrow">GIJÓN · ASTURIAS · DESDE 1978</p>
      </div>
    </footer>
  );
}
