# Architecture
- Keep public navigation on the retained home, company and contact routes to avoid links into removed sections.
- The brand logo ships in two lockups: full colour (`vir-logo.svg`) on light ground and a knockout (`vir-logo-light.svg`) whenever it sits over a photo, because the burgundy in the mark is mid-tone and disappears on imagery.
